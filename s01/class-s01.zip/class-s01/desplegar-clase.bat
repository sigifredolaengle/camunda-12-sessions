@echo off
rem Despliega en Camunda la clase guiada de esta carpeta (modelo y formularios)
rem y abre Tasklist en la pestana Procesos para iniciarla.
setlocal
cd /d "%~dp0"

curl.exe -s -o nul http://localhost:8080/v2/topology
if errorlevel 1 (
  echo Camunda no esta corriendo. Haga doble clic en "Iniciar Camunda", espere
  echo a que se abran Operate y Tasklist, y vuelva a ejecutar este archivo.
  pause
  exit /b 1
)

set "FALLAS=0"
for %%F in (*.form *.dmn *.bpmn) do call :desplegar "%%F"
if not "%FALLAS%"=="0" (
  echo.
  echo %FALLAS% archivo^(s^) no se pudieron desplegar. Avise al profesor.
  pause
  exit /b 1
)

echo.
echo Listo. En Tasklist, pestana Procesos, inicie la clase de hoy.
start "" "http://127.0.0.1:8080/tasklist/processes"
timeout /t 8 >nul
exit /b 0

:desplegar
set "CODIGO="
for /f %%C in ('curl.exe -s -o nul -w "%%{http_code}" -X POST http://localhost:8080/v2/deployments -F "resources=@%~1"') do set "CODIGO=%%C"
if "%CODIGO%"=="200" (
  echo   desplegado: %~1
) else (
  echo   ERROR %CODIGO%: %~1
  set /a FALLAS+=1
)
exit /b 0
