#!/bin/sh
# Despliega en Camunda la clase guiada de esta carpeta (modelo y formularios)
# y abre Tasklist en la pestana Procesos para iniciarla. macOS (doble clic) y Linux
# (sh desplegar-clase.command).
cd "$(dirname "$0")" || exit 1
if ! curl -s -o /dev/null http://localhost:8080/v2/topology; then
  echo "Camunda no esta corriendo. Inicielo (./start.sh) y vuelva a ejecutar este archivo."
  printf "Presione Enter para cerrar. "; read -r _
  exit 1
fi
fallas=0
for f in *.form *.dmn *.bpmn; do
  [ -e "$f" ] || continue
  code=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:8080/v2/deployments -F "resources=@$f")
  if [ "$code" = "200" ]; then echo "  desplegado: $f"; else echo "  ERROR $code: $f"; fallas=$((fallas+1)); fi
done
if [ "$fallas" -ne 0 ]; then
  echo "$fallas archivo(s) no se pudieron desplegar. Avise al profesor."
  printf "Presione Enter para cerrar. "; read -r _
  exit 1
fi
echo "Listo. En Tasklist, pestana Procesos, inicie la clase de hoy."
url="http://127.0.0.1:8080/tasklist/processes"
command -v open >/dev/null && open "$url" || xdg-open "$url" 2>/dev/null
printf "Presione Enter para cerrar. "; read -r _
